/*
 * mergesort.h
 *
 *  Created on: May 7, 2016
 *      Author: Conor
 */

#ifndef MERGESORT_H_
#define MERGESORT_H_

class mergesort {
public:
	mergesort();
	virtual ~mergesort();
};

#endif /* MERGESORT_H_ */
