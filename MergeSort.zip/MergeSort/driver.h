/*
 * driver.h
 *
 *  Created on: May 7, 2016
 *      Author: Conor
 */

#ifndef DRIVER_H_
#define DRIVER_H_

class driver {
public:
	driver();
	virtual ~driver();
};

#endif /* DRIVER_H_ */
