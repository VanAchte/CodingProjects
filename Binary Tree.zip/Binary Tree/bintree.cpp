// ------------------------------------------------ bintree.cpp -------------------------------------------------------
//
// Programmer Name: Conor Van Achte CSS343
// Creation Date: October 12, 2016
// Date of Last Modification: October 12, 2016
// --------------------------------------------------------------------------------------------------------------------
// Purpose: Allows creation of a BinaryTree which reads through a data file consisting of many lines, separated by $$.
//          Creates new nodedata which contains strings with an undetermined length. Duplicated strings will be discarded,
//          smaller strings go to the left, larger strings to the right, alphabetically ordered.
// --------------------------------------------------------------------------------------------------------------------
// Notes:
// --------------------------------------------------------------------------------------------------------------------
#include "bintree.h"
using namespace std;
// ------------------------------------BinTree--------------------------------------
// Description: No argument constructor. Allocates memory for each part of the tree.
// ---------------------------------------------------------------------------------
BinTree::BinTree() {
	root = NULL;

}
// ------------------------------------BinTree------------------------------------
// Description: Copy Constructor
// ----------------------------------------------------------------------------
BinTree::BinTree(const BinTree &copy) {
	root = NULL;
	*this = copy;
}

// ------------------------------------operator~------------------------------------
// Description: Destructor, delete the memory allocated for this tree's nodes.
// ----------------------------------------------------------------------------
BinTree::~BinTree() {
	makeEmpty();
}
// ------------------------------------bstreeToArray------------------------------------
// Description:
// ----------------------------------------------------------------------------

bool BinTree::retrieve(const NodeData &find, NodeData* &ptr) const {
	if (root == NULL) {
		return false;
	} else {
		return retrieve(find, ptr, root);
	}
}
bool BinTree::retrieve(const NodeData &find, NodeData* &ptr,
		Node* currentNode) const {
	if (*currentNode->data == find) {
		ptr = currentNode->data;
		return true;
	} else if (*currentNode->data > find) {
		if (currentNode->left == NULL) {
			return false;
		} else {
			retrieve(find, ptr, currentNode->left);
		}
	} else if (*currentNode->data < find) {
		if (currentNode->right == NULL) {
			return false;
		} else {
			retrieve(find, ptr, currentNode->right);
		}
	}
	return false;
}
// else if(find < *currentNode->data) {
//    	retrieve(find, ptr, currentNode->left);
//    } else if( find > *currentNode->data) {
//    	retrieve(find, ptr, currentNode->right);
//    }
// ------------------------------------operator=------------------------------------
// Description: Overloaded assignment operator. Takes in a BinTree and assign the
//              current object to the object passed in.
// ----------------------------------------------------------------------------
BinTree &BinTree::operator=(const BinTree &rhs) {
	this->makeEmpty();
	root = NULL;
	this->copy(rhs.root);
	return *this;
}
void BinTree::copy(Node* current) {
	if (current != NULL) {
		NodeData* add = new NodeData(*current->data);
		insert(add);
		copy(current->left);
		copy(current->right);
	}
}
bool BinTree::insert(NodeData* add) {
	return insert(add, root);
}
bool BinTree::insert(NodeData* addData, Node*& currentNode) {
	if (currentNode == NULL) {
		currentNode = new Node();
		currentNode->data = addData;
		currentNode->left = NULL;
		currentNode->right = NULL;
		return true;
	} else if (*addData < *currentNode->data) {
		return insert(addData, currentNode->left);
	} else if (*addData > *currentNode->data) {
		return insert(addData, currentNode->right);
	}
	// If the data has been added already we return false.
	return false;
}
// ------------------------------------operator==------------------------------------
// Description: Compares two BinTree objects to see if they are equal or not.
// ----------------------------------------------------------------------------
bool BinTree::operator==(const BinTree& rhs) const {
	this->compare(rhs.root);
	return true;
}
bool BinTree::compare(Node* rhs) const {
//    if(root->data != rhs->data) {
//    	return false;
//    } else {
//    	if((rhs->right == NULL && right != NULL) || (rhs->right != NULL && right == NULL)) {
//    		return false;
//    	} else if((rhs->left == NULL && left != NULL) || (rhs->left != NULL && left == NULL)) {
//    		return false;
//    	}
//    	compare(rhs->left);
//    	compare(rhs->right);
//    }
	return true;
}
//BinTree &BinTree::operator=(const BinTree &rhs) {
//	 this->makeEmpty();
//	 root = NULL;
//	 this->copy(rhs.root);
//	return *this;
//}
//void BinTree::copy(Node* current) {
//    if(current != NULL) {
//        insert(current->data);
//    	copy(current->left);
//        copy(current->right);
//    }
//}
// ------------------------------------operator!=------------------------------------
// Description: Overloaded != operator. Compares two BinTree objects
// ----------------------------------------------------------------------------
bool BinTree::isEmpty() const {
	return root == NULL;

}
void BinTree::makeEmpty() {
	if (!isEmpty()) {
		makeEmpty(root);
	}
}
void BinTree::makeEmpty(Node* &current) {
	if (current != NULL) {
		makeEmpty(current->left);
		makeEmpty(current->right);
		delete current->data;
		delete current;
	}
}

bool BinTree::operator!=(const BinTree& rhs) const {
	return !(*this == rhs);

}
//-------------------------- operator<< --------------------------------------
ostream& operator<<(ostream& output, const BinTree &print) {

	//output << print.displaySideways();
	return output;
}

//------------------------- displaySideways ---------------------------------
// Displays a binary tree as though you are viewing it from the side;
// hard coded displaying to standard output.
// Preconditions: NONE
// Postconditions: BinTree remains unchanged.
void BinTree::displaySideways() const {
	sideways(root, 0);
}

//---------------------------- Sideways -------------------------------------
// Helper method for displaySideways
// Preconditions: NONE
// Postconditions: BinTree remains unchanged.
void BinTree::sideways(Node* current, int level) const {
	if (current != NULL) {
		level++;
		sideways(current->right, level);

		// indent for readability, 4 spaces per depth level
		for (int i = level; i >= 0; i--) {
			cout << "    ";
		}

		cout << *current->data << endl;        // display information of object
		sideways(current->left, level);
	}
}
