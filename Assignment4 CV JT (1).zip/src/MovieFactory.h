/*
 * MovieFactory.h
 *
 *  Created on: Dec 11, 2016
 *      Author: ConorV
 */

#ifndef MOVIEFACTORY_H_
#define MOVIEFACTORY_H_
using namespace std;
#include "MovieFactory.h"
#include "Movie.h"

class MovieFactory{
public:
	static Movie* returnMovie(char);
};

#endif /* MOVIEFACTORY_H_ */
