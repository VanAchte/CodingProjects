/*
 * Movie.h
 *
 *  Created on: Dec 8, 2016
 *      Author: Conor
 */

#ifndef MOVIE_H_
#define MOVIE_H_

#include <string>
#include <iostream>
#include <fstream>
#include <string>

using namespace std;

class Movie {
	friend ostream& operator<<(ostream&, const Movie&);

public:
	Movie();
	Movie(char,string);

    Movie(ifstream&);

    int getStock();

    virtual bool operator==(const Movie&) const;
	virtual bool operator<(const Movie&) const;
	virtual bool operator>(const Movie&) const;
    virtual void setYear(int);
	virtual char getGenre();
	virtual void setMajorActor(string);
    string getDirector();

	virtual void printMovie();


    int setYear();
    virtual void setTitle(string);
	virtual void setDirector(string);
    virtual int getYear();
    string getMajorActor();
    string getTitle();
    int getMonth();
    Movie* getMovie();
    virtual void setStock(int);
	virtual void setMonth(int);
    virtual void buildMovie(string);
	//	NodeData(const string &);      // data is set equal to parameter
	//	NodeData(const NodeData &);    // copy constructor
	//	NodeData& operator=(const NodeData &);

	//	// set class data from data file
	//	// returns true if the data is set, false when bad data, i.e., is eof
	//	bool setData(istream&);

	 ~Movie();

protected:
	 virtual string getUntilComma(string);
	 virtual string getUntilSpace(string);
     virtual int stringToInt(string);
     virtual string removeToComma(string);
     virtual string removeToSpace(string);
	struct date{
		int month;
		int day;
		int year;
	};

	int stock;
	date releaseDate;
	string type;
	string title;
	string majorActor;
	string director;
};

#endif /* MOVIE_H_ */
