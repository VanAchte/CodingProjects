// ------------------------------------------------ driver.cpp --------------------------------------------------------
// Class:			CSS 343A
// Programmer Name:	Conor Van Achte & Jeffery Taylor
// Creation Date:	November 29, 2016
// --------------------------------------------------------------------------------------------------------------------
// Purpose: The main driver .cpp
// --------------------------------------------------------------------------------------------------------------------

#include "Classics.h"
#include "Customer.h"
#include "Comedy.h"
#include "Customer.h"
#include "Database.h"
#include "Drama.h"
#include "Movie.h"
#include "HashTable.h"

using namespace std;

int main() {
    cout << "Hello world" << endl;
	
	// Creates the Storage system for the movies and the customers.
    Database* storage = new Database();

	// Reads in the 3 data files.
	ifstream infile("data4customers.txt");
	if (!infile) {
		cout << "File could not be opened." << endl;
		return 1;
	}

	ifstream infile2("data4movies.txt");
	if (!infile2) {
		cout << "File2 could not be opened." << endl;
		return 1;
	}

	ifstream infile3("data4commands.txt");
	if (!infile3) {
		cout << "File3 could not be opened." << endl;
		return 1;
	}

	// Begins processing in the files.
	storage->buildCustomers(infile);
	storage->buildMovies(infile2);
	storage->buildTransaction(infile3);
	delete storage;
	return 0;
}

