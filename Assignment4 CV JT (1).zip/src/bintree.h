// ------------------------------------------------ bintree.h -------------------------------------------------------
//
// Programmer Name: Conor Van Achte CSS343
// Creation Date: October 12, 2016
// Date of Last Modification: October 12, 2016
// --------------------------------------------------------------------------------------------------------------------
// Purpose: Allows creation of a BinaryTree which reads through a data file consisting of many lines, separated by $$.
//          Creates new Movie which contains strings with an undetermined length. Duplicated strings will be discarded,
//          smaller strings go to the left, larger strings to the right, alphabetically ordered.
// --------------------------------------------------------------------------------------------------------------------
// Notes:
// --------------------------------------------------------------------------------------------------------------------
#include "Movie.h"
using namespace std;
class BinTree {				// you add class/method comments and assumptions
	friend ostream &operator<<(ostream &out, const BinTree &rhs);
public:
	BinTree();								// constructor
	BinTree(const BinTree &);				// copy constructor
	~BinTree();								// destructor, calls makeEmpty
	bool isEmpty() const;			// true if tree is empty, otherwise false
	void makeEmpty();			// make the tree empty so isEmpty returns true
	BinTree& operator=(const BinTree &);
	bool operator==(const BinTree &) const;
	bool operator!=(const BinTree &) const;
	bool insert(Movie*);
	bool retrieve(const Movie &find, Movie* &ptr);
	void displaySideways() const;// provided below, displays the tree sideways
	int getHeight(const Movie &) const;

	void bstreeToArray(Movie* []);
	void arrayToBSTree(Movie* []);
private:

	struct Node {
		Movie* data;						// pointer to data object
		Node* left;							// left subtree pointer
		Node* right;						// right subtree pointer
	};

	Node* root;								// root of the tree
	// Private helper functions
	bool retrieve(const Movie &, Movie* &, Node*);
	bool insert(Movie*, Node*&);
	void makeEmpty(Node* &);
	void copy(Node* current);
	int getHeight(int, Node *&) const;
	bool compareObjects(Node*, Node*) const;
	bool findNode(const Movie&, Node*, Node*&) const;
	void bstreeToArray(Node* &, Movie* [], int &);
	void arrayToBSTreeHelper(Movie* [], Node*& , int, int);
// utility functions
	void inorderHelper(... ) const;
	void sideways(Node*) const;// provided below, helper for displaySideways()

};
