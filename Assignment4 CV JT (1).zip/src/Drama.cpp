/*
 * Drama.cpp
 *
 *  Created on: Dec 9, 2016
 *      Author: ConorV
 */
#include"Drama.h"

Drama::Drama(){

}
// ------------------------------------printMovie------------------------------------
// Description: Prints out the details of the movie
// ---------------------------------------------------------------------------------
void Drama::printMovie(){
		cout << "Genre: " << getGenre() << " Stock: "
			<< getStock() << " Director: " << getDirector()
			<< " Title: " << getTitle() 
			<< " Release Year: " << getYear()
			<< endl << endl;
}
// ------------------------------------setStock------------------------------------
// Description: Sets the stock of whatever number is passed in
// ---------------------------------------------------------------------------------
void Drama::setStock(int n) {
	stock = n;
}
// ------------------------------------getGenre------------------------------------
// Description: Returns the genre.
// ---------------------------------------------------------------------------------
char Drama::getGenre() {
	return 'D';
}
// ------------------------------------getYear------------------------------------
// Description: Returns the year.
// ---------------------------------------------------------------------------------
int Drama::getYear() {
	return releaseDate.year;
}
// ------------------------------------getDirector------------------------------------
// Description: Returns the director
// ---------------------------------------------------------------------------------
string Drama::getDirector() {
	return director;
}
// ------------------------------------buildMovie------------------------------------
// Description: Builds the movie based on the string passed in.
// ---------------------------------------------------------------------------------
void Drama::buildMovie(string line) {
    string data = line;
    string temp = data;
	data = getUntilComma(line);

	stock = stringToInt(data);
    data = removeToComma(line);

    temp = getUntilComma(data);
    director = temp;

    data = removeToComma(data);

    temp = data;
    title = getUntilComma(temp);


    data = removeToComma(data);

    //releaseDate.year = stringToInt(data);
    data = getUntilSpace(data);
    releaseDate.year = stringToInt(data);
}
// ------------------------------------operator==------------------------------------
// Description: Takes in a Movie as a parameter and converts it to a Drama,
//              and compares based on the criteria.
// ---------------------------------------------------------------------------------
bool Drama::operator==(const Movie & rhs) const {
	const Drama& r = static_cast<const Drama&>(rhs);
	return (title == r.title && director == r.director);
}
// ------------------------------------operator==------------------------------------
// Description: Takes in a Drama as a parameter and compares based on the criteria.
// ---------------------------------------------------------------------------------
bool Drama::operator==(const Drama & rhs) const {

	return (title == rhs.title && director == rhs.director);
}
// ------------------------------------operator>------------------------------------
// Description: Takes in a Movie object and converts it into a Drama then
//              compares by the criteria
// ---------------------------------------------------------------------------------
bool Drama::operator>(const Movie &rhs) const {
	const Drama& rhS = static_cast<const Drama&>(rhs);

	if (director > rhS.director)
		return true;
	else if(director == rhS.director && title > rhS.title)
		return true;
	else
		return false;
}
// ------------------------------------operator>------------------------------------
// Description: Takes in a Drama and compares the Dramas.
// ---------------------------------------------------------------------------------
bool Drama::operator>(const Drama &rhs) const {
	if (director > rhs.director)
		return true;
	else if(director == rhs.director && title > rhs.title)
		return true;
	else
		return false;
}
// ------------------------------------operator<------------------------------------
// Description: Takes in a Movie object and converts it into a Drama then
//              compares by the criteria
// ---------------------------------------------------------------------------------
bool Drama::operator<(const Movie &rhs) const {
	const Drama& rhS = static_cast<const Drama&>(rhs);

	if (director < rhS.director)
		return true;
	else if(director == rhS.director && title < rhS.title)
		return true;
	else
		return false;
}
// ------------------------------------operator<------------------------------------
// Description: Takes in a Movie object and compares Dramas.
// ---------------------------------------------------------------------------------
bool Drama::operator<(const Drama &rhs) const {
	if (director < rhs.director)
		return true;
	else if(director == rhs.director && title < rhs.title)
		return true;
	else
		return false;
}
// ------------------------------------~Drama------------------------------------
// Description: Destructor.
// ---------------------------------------------------------------------------------
Drama::~Drama(){

}
