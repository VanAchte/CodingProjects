/*
 * MovieFactory.cpp
 *
 *  Created on: Dec 11, 2016
 *      Author: ConorV
 */
#include "MovieFactory.h"
#include "Movie.h"
#include "Drama.h"
#include "Classics.h"
#include "Comedy.h"

Movie* MovieFactory::returnMovie(char type) {
    if(type == 'C'){
        Classics* c = new Classics();
        return c;
    }
    else if(type == 'F') {
    	Comedy* f = new Comedy();
    	return f;
    }
    else if(type == 'D') {
        Drama* d = new Drama();
        return d;
    }
    else {
    	cout << "ERROR: Movie Genre not found." << endl;
        return NULL;
    }
}



