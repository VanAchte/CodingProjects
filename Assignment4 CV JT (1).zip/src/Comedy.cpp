/*
 * Comedy.cpp
 *
 *  Created on: Dec 9, 2016
 *      Author: ConorV
 */
#include "Comedy.h"

#include <sstream>
#include <iostream>
#include <string>

using namespace std;
// ------------------------------------Comedy-----------------------------------
// Description: Default Constructor
// ---------------------------------------------------------------------------------
Comedy::Comedy() {

}
// ------------------------------------Comedy-----------------------------------
// Description: One paramater constructor, takes in a string and sets the data
//              from the string into the fields.
// ---------------------------------------------------------------------------------
Comedy::Comedy(string temp) {
	setData(temp);
}
// ------------------------------------printMovie-----------------------------------
// Description: Prints out the movie information.
// ---------------------------------------------------------------------------------
void Comedy::printMovie(){
	cout << "Genre: " << getGenre() << " Stock: "
		<< getStock() << " Director: " << getDirector()
		<< " Title: " << getTitle()
		<< " Release Year: " << getYear()
		<< endl << endl;
}
// ------------------------------------setData-----------------------------------
// Description: Takes in a string which it parses through and sets the director
// ---------------------------------------------------------------------------------
void Comedy::setData(string s) {

	for (int i = 0; i < s.length(); i++) {
		director += s.at(i);
	}
}
// ------------------------------------getGenre-----------------------------------
// Description: Returns genre.
// ---------------------------------------------------------------------------------
char Comedy::getGenre() {
	return 'F';
}
// ------------------------------------buildMovie-----------------------------------
// Description: Builds the movie with the paramater string that is passed in.
// ---------------------------------------------------------------------------------
void Comedy::buildMovie(string line) {
	string data = line;
	string temp = data;
	data = getUntilComma(line);

	stock = stringToInt(data);
	data = removeToComma(line);

	temp = getUntilComma(data);
	director = temp;

	data = removeToComma(data);

	temp = data;
	title = getUntilComma(temp);

	data = removeToComma(data);

	data = getUntilSpace(data);
	releaseDate.year = stringToInt(data);

}
// ------------------------------------operator==-----------------------------------
// Description: Takes in a Movie and casts it to a Comedy. The Comedies are then
//              compared.
// ---------------------------------------------------------------------------------
bool Comedy::operator==(const Movie & rhs) const {
	const Comedy& r = static_cast<const Comedy&>(rhs);
	return (title == r.title && releaseDate.year == r.releaseDate.year);
}
// ------------------------------------operator==-----------------------------------
// Description: Takes in a Comedy and compares the two Comedies
// ---------------------------------------------------------------------------------
bool Comedy::operator==(const Comedy & rhs) const {
	return (title == rhs.title && releaseDate.year == rhs.releaseDate.year);
}
// ------------------------------------operator>-----------------------------------
// Description: Takes a Movie as a parameter and casts it to a Comedy, then it's
//              compared.
// ---------------------------------------------------------------------------------
bool Comedy::operator>(const Movie &rhs) const {
	const Comedy& rhS = static_cast<const Comedy&>(rhs);

	if (title > rhS.title)
		return true;
	else if(title == rhS.title && releaseDate.year > rhS.releaseDate.year)
		return true;
	else
		return false;
}
// ------------------------------------operator>-----------------------------------
// Description: Compares comedies based on criteria
// ---------------------------------------------------------------------------------
bool Comedy::operator>(const Comedy &rhs) const {

	if (title > rhs.title)
		return true;
	else if(title == rhs.title && releaseDate.year > rhs.releaseDate.year)
		return true;
	else
		return false;
}

// ------------------------------------operator<-----------------------------------
// Description: Takes a Movie as a parameter and casts it to a Comedy, then it's
//              compared.
// ---------------------------------------------------------------------------------
bool Comedy::operator<(const Movie &rhs) const {
	const Comedy& rhS = static_cast<const Comedy&>(rhs);

	if (title < rhS.title)
		return true;
	else if(title == rhS.title && releaseDate.year < rhS.releaseDate.year)
		return true;
	else
		return false;
}
// ------------------------------------operator<-----------------------------------
// Description: Takes a Movie as a parameter and casts it to a Comedy, then it's
//              compared.
// ---------------------------------------------------------------------------------
bool Comedy::operator<(const Comedy &rhs) const {
	if (title < rhs.title)
		return true;
	else if(title == rhs.title && releaseDate.year < rhs.releaseDate.year)
		return true;
	else
		return false;
}
// ------------------------------------~Comedy-----------------------------------
// Description: Destructor for Comedy
// ---------------------------------------------------------------------------------
Comedy::~Comedy() {

}
