#ifndef DATABASE_H_
#define DATABASE_H_

#include <iostream>
#include <fstream>
#include <sstream>

#include "Classics.h"
#include "Drama.h"
#include "Comedy.h"
#include "Customer.h"
#include "HashTable.h"
#include "Movie.h"
#include "bintree.h"

using namespace std;

class Database {
public:
	// Default Constructor & Destructor.
	Database();
	~Database();

	void buildMovies(ifstream&);
	void buildCustomers(ifstream&);
	void buildTransaction(ifstream&);

	void parseCommand(string);
	void displayInventory();
	void printTransactionHistory(int);

    // Moved to public temporarily for testing, may need to move back to
	// private before turning in project.
	BinTree* dramas;
    BinTree* comedies;
    BinTree* classics;
    HashTable* customers;
	
private:
	// Takes the entire line of command from the file
    bool addMovie(string); 
	bool addCustomer(int, string);
	void printCustomers();
	
	vector<Customer*> custVector;
	int stringToInt(string);
	string removeToSpace (string);
	string getUntilSpace(string);
	string getUntilComma(string);
	string getRestofLine(string);
	string removeToComma(string);
};

#endif /* DATABASE_H_ */
