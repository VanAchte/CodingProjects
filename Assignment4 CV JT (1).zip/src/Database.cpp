/*
 * Database.cpp
 *
 *  Created on: Dec 8, 2016
 *      Author: Conor
 */

#include "Customer.h"
#include <vector>
#include "MovieFactory.h"
#include "Database.h"

// ------------------------------------Database-------------------------------------
// Description: No argument constructor. Initializes the trees.
// ---------------------------------------------------------------------------------
Database::Database() {
    comedies = new BinTree();
    classics = new BinTree();
    dramas = new BinTree();
}

// ------------------------------------~Database------------------------------------
// Description: Destructs the database and ensures no memory leaks.
// ---------------------------------------------------------------------------------
Database::~Database() {
	delete comedies;
	delete classics;
	delete dramas;
}

// ------------------------------------buildMovies----------------------------------
// Description: Takes in the file from the driver and puts the movies into one of
//				the 3 trees based on genre.
// ---------------------------------------------------------------------------------
void Database::buildMovies(ifstream& infile) {
	string temp;
	char genre;

	while (!infile.eof()) {
		getline(infile, temp);

		if (temp != "") {
			genre = temp.at(0);
			temp = temp.substr(3, temp.length() - 1);
			Movie* m = MovieFactory::returnMovie(genre);

			if (m != NULL) {

				m->buildMovie(temp);
				if(genre == 'F'){
					comedies->insert(m);
					Movie *f;
					comedies->retrieve(*m, f);
				}else if (genre == 'D'){
					dramas->insert(m);
					Movie *d;
					dramas->retrieve(*m, d);
				}
				else if (genre == 'C'){
					classics->insert(m);
					Movie *c;
					classics->retrieve(*m, c);
				}else
					cout << "ERROR: Movie Genre not found." << endl;
				
			}
		}
	}
}

// ---------------------------------buildCustomers----------------------------------
// Description: Takes in the file from the driver and puts the customers into the
//				hashtable.
// ---------------------------------------------------------------------------------
void Database::buildCustomers(ifstream& infile) {
	// id set to one to check if we have hit the end of the line in
	// the while loop. id gets reset to one at the end of each customer
	int id = 1;
	string firstName;
	string lastName;
	int size = 0;
	while (!infile.eof()) {
		// Will work for customer list with disney characters

		infile >> id;
		if (id == 1) {
			break;
		}
		infile >> firstName;
		infile >> lastName;
		Customer* addCustomer = new Customer(id, firstName, lastName);
		custVector.push_back(addCustomer);
		size++;
		id = 1;

	}
	customers = new HashTable(size);
	int numCustomers = custVector.size();
	for (int i = 0; i < numCustomers; i++) {
		customers->add(custVector.at(i)->getId(), custVector.at(i));
	}
}

// ------------------------------------buildTransactions----------------------------
// Description: Takes in the file from the driver and interprets the different
//				transaction types then determines what to do.
// ---------------------------------------------------------------------------------
void Database::buildTransaction(ifstream& infile){
	string temp = "";
	char typeT;
	while (!infile.eof()) {

		getline(infile, temp);

		if (infile.eof()){
			break;
		}

		if (temp != "") {

			typeT = temp.at(0);
			temp = removeToSpace(temp);

			if (typeT == 'I'){
				displayInventory();

			}
			else if (typeT == 'H'){

				string idString = getUntilSpace(temp);

				int id = stringToInt(temp);

				Customer* h = customers->retrieve(id);
				if (h != NULL){
					cout << "customer id: ";
					int idPrint = h->getId();
					cout << idPrint << endl;
					h->displayHistory();
				}
			}
			else if (typeT == 'B'){

				string idString = getUntilSpace(temp);

				int id = stringToInt(temp);
				Customer* b = customers->retrieve(id);

				temp = removeToSpace(temp);
				idString = getUntilSpace(temp);
				string typeofMedia = idString;

				temp = removeToSpace(temp);
				idString = getUntilSpace(temp);
				char genre = idString.at(0);

				if (genre == 'F') {
					temp = removeToSpace(temp);
					idString = getUntilComma(temp);
					string movieName = idString;

					temp = removeToComma(temp);
					int year = stringToInt(temp);

					Movie* m = MovieFactory::returnMovie('F');
					m->setTitle(movieName);
					m->setYear(year);
					Movie* temp;

					comedies->retrieve(*m, temp);

					if (temp != NULL) {
						if (temp->getStock() > 0){
							temp->setStock(temp->getStock() - 1);
							b->initTransaction(genre, temp);
							b->addTransaction();
						}
						else
							cout << "ERROR: No stock for current movie." << endl;
					}
				}
				else if (genre == 'D') {
					temp = removeToSpace(temp);

					idString = getUntilComma(temp);
					string directorName = idString;

					temp = removeToComma(temp);
					string title = getUntilComma(temp);

					Movie* m = MovieFactory::returnMovie('D');
					m->setDirector(directorName);
					m->setTitle(title);

					Movie* temp = NULL;

					dramas->retrieve(*m, temp);

					if (temp != NULL) {
						if (temp->getStock() > 0){
							temp->setStock(temp->getStock() - 1);
							b->initTransaction(genre, temp);
							b->addTransaction();
						}else
							cout << "ERROR: No stock for current movie." << endl;
					}
				}
				else if (genre == 'C') {

					temp = removeToSpace(temp);
					string Smonth = getUntilSpace(temp);
					int month = stringToInt(Smonth);

					temp = removeToSpace(temp);
					string Syear = getUntilSpace(temp);
					int year = stringToInt(Syear);

					temp = removeToSpace(temp);
					string majorActor = getUntilSpace(temp);
					temp = removeToSpace(temp);
					majorActor += " ";
					majorActor += getUntilSpace(temp);

					Movie* m = MovieFactory::returnMovie('C');
					m->setMonth(month);
					m->setYear(year);
					m->setMajorActor(majorActor);

					Movie* temp = NULL;

					classics->retrieve(*m, temp);

					if (temp != NULL) {
						if (temp->getStock() > 0){
							temp->setStock(temp->getStock() - 1);
							if (b){
								b->initTransaction(genre, temp);
								b->addTransaction();
							}
						}
						else
							cout << "ERROR: No stock for current movie." << endl;
					}
				}
			}
			else if (typeT == 'R'){
				string idString = getUntilSpace(temp);

				int id = stringToInt(temp);
				Customer* r = customers->retrieve(id);

				temp = removeToSpace(temp);
				idString = getUntilSpace(temp);
				string typeofMedia = idString;

				temp = removeToSpace(temp);
				idString = getUntilSpace(temp);
				char genre = idString.at(0);

				if (genre == 'F') {
					temp = removeToSpace(temp);
					idString = getUntilComma(temp);
					string movieName = idString;

					temp = removeToComma(temp);
					int year = stringToInt(temp);

					Movie* m = MovieFactory::returnMovie('F');
					m->setTitle(movieName);
					m->setYear(year);
					Movie* temp;

					comedies->retrieve(*m, temp);

					if (temp != NULL) {
						temp->setStock(temp->getStock() + 1);
						r->initTransaction(genre, temp);
						r->addTransaction();
					}
				}
				else if (genre == 'D') {
					temp = removeToSpace(temp);

					idString = getUntilComma(temp);
					string directorName = idString;

					temp = removeToComma(temp);
					string title = getUntilComma(temp);

					Movie* m = MovieFactory::returnMovie('D');
					m->setDirector(directorName);
					m->setTitle(title);

					Movie* temp = NULL;

					dramas->retrieve(*m, temp);

					if (temp != NULL) {
							temp->setStock(temp->getStock() + 1);
							r->initTransaction(genre, temp);
							r->addTransaction();
					}

				}
				else if (genre == 'C') {

					temp = removeToSpace(temp);
					string Smonth = getUntilSpace(temp);
					int month = stringToInt(Smonth);

					temp = removeToSpace(temp);
					string Syear = getUntilSpace(temp);
					int year = stringToInt(Syear);

					temp = removeToSpace(temp);
					string majorActor = getUntilSpace(temp);
					temp = removeToSpace(temp);
					majorActor += " ";
					majorActor += getUntilSpace(temp);

					Movie* m = MovieFactory::returnMovie('C');
					m->setMonth(month);
					m->setYear(year);
					m->setMajorActor(majorActor);

					Movie* temp = NULL;

					classics->retrieve(*m, temp);

					if (temp != NULL) {
						temp->setStock(temp->getStock() + 1);
						if (r){
							r->initTransaction(genre, temp);
							r->addTransaction();
						}
					}
				}
				else
					cout << "ERROR: Unknown transaction type" << endl;
			}
		}
	}
}


// ------------------------------------displayInventory---------------------------------
// Description: Displays the sorted movies from the trees based on each genres criteria
// -------------------------------------------------------------------------------------
void Database::displayInventory(){
	cout << "This is the Inventory:" << endl;
	comedies->displaySideways();
	dramas->displaySideways();
	classics->displaySideways();
}

// ------------------------------------getRestOfLine--------------------------------
// Description: Used for parsing the strings until a space.
// ---------------------------------------------------------------------------------
string Database::getRestofLine(string s) {
    return " ";
}

// ------------------------------------removeToSpace--------------------------------
// Description: Parses through a string until it reaches a space.
// ---------------------------------------------------------------------------------
string Database::removeToSpace(string mod) {
    string newString = "";
    int length = mod.length();
    for(int i = 0; i < length; i++) {
    	if(mod.at(i) == ' ') {
    		// If we hit a ' ' then return a string + 2 from the space
    		// to get rid of the space and the space between data values.
    		newString = mod.substr(i + 1, mod.length() - 1);
    		break;
    	}
    }
	return newString;
}

// ------------------------------------getUntilComma--------------------------------
// Description: Gets everything in a string up to a comma.
// ---------------------------------------------------------------------------------
string Database::getUntilComma(string s) {
    string total = "";
    int length = s.length();
    for(int i = 0; i < length; i++) {
    	if(s.at(i) == ',') {
    		break;
    	}
    	total = total + s.at(i);
    }
	return total;
}

// ------------------------------------getUntilSpace--------------------------------
// Description: Gets everything in a string until a space.
// ---------------------------------------------------------------------------------
string Database::getUntilSpace(string s) {
    string total = "";
    int length = s.length();
    for(int i = 0; i < length; i++) {
    	if(s.at(i) == ' ') {
    		break;
    	}
    	total = total + s.at(i);
    }
	return total;
}

int Database::stringToInt(string s) {
	int total;
	stringstream convert(s);
	if( !(convert >> total) ) {
		total = 0;
	}
	return total;
}

string Database::removeToComma(string mod) {
	string newString = "";
	int length = mod.length();
	for (int i = 0; i < length; i++) {
		if (mod.at(i) == ',') {
			// If we hit a ',' then return a string + 2 from the comma
			// to get rid of the comma and the space between data values.
			newString = mod.substr(i + 2, mod.length() - 1);
			break;
		}
	}
	return newString;
}
