/*
 * Classic.cpp
 *
 *  Created on: Dec 9, 2016
 *      Author: ConorV
 */

#include "Classics.h"
// ------------------------------------Classics-----------------------------------
// Description: Default constructor
// ---------------------------------------------------------------------------------
Classics::Classics() {

}

// ------------------------------------getGenre-----------------------------------
// Description: Returns the genre.
// ---------------------------------------------------------------------------------
char Classics::getGenre() {
	return 'C';
}

// ------------------------------------printMovie-----------------------------------
// Description: Prints out the details of the movie.
// ---------------------------------------------------------------------------------
void Classics::printMovie(){
	cout << "Genre: " << getGenre() << " Stock: "
		<< getStock() << " Director: " << getDirector()
		<< " Title: " << getTitle() << " Major Actor: "
		<< getMajorActor() << " Release Month: "
		<< getMonth() << " Release Year: " << getYear()
		<< endl << endl;
}

// ------------------------------------buildMovie-----------------------------------
// Description: Takes in a string which is then parsed and added to the BinaryTree
//              of the specified genre.
// ---------------------------------------------------------------------------------
void Classics::buildMovie(string line) {

		string data = line;
		string temp = data;
        // Set the stock
		data = getUntilComma(line);
		stock = stringToInt(data);
		data = removeToComma(line);

		// Set the director
		temp = getUntilComma(data);
		director = temp;
		data = removeToComma(data);

		//Set the title of the movie
		temp = data;
		title = getUntilComma(temp);
		data = removeToComma(data);

		//Set the major actor if there is one.
		temp = data;
		majorActor = getUntilSpace(temp);
		temp = getUntilSpace(temp);
		data = removeToSpace(data);
		temp = data;
		temp = getUntilSpace(data);
		majorActor += " ";
		majorActor += temp;

		//Set release date.
		data = removeToSpace(data);
		temp = removeToSpace(data);
		data = getUntilSpace(data);
		releaseDate.month = stringToInt(data);
		releaseDate.year = stringToInt(temp);

}

// ------------------------------------~Classics------------------------------------
// Description: Destructor.
// ---------------------------------------------------------------------------------
Classics::~Classics() {

}

// ------------------------------------operator==------------------------------------
// Description: Takes in a Movie, converts it into a Classic and and compares.
// ---------------------------------------------------------------------------------
bool Classics::operator==(const Movie & rhs) const {
	const Classics& r = static_cast<const Classics&>(rhs);
	return (releaseDate.month == r.releaseDate.month &&
			releaseDate.year == r.releaseDate.year &&
			majorActor == r.majorActor);
}
// ------------------------------------operator==------------------------------------
// Description: Compares Classics
// ---------------------------------------------------------------------------------
bool Classics::operator==(const Classics & rhs) const {

	return (releaseDate.month == rhs.releaseDate.month &&
				releaseDate.year == rhs.releaseDate.year &&
				majorActor == rhs.majorActor);
}

// ------------------------------------operator>------------------------------------
// Description: Takes a Movie in as a parameter and converts it into a Classic,
//              and compares it.
// ---------------------------------------------------------------------------------
bool Classics::operator>(const Movie &rhs) const {
	const Classics& r = static_cast<const Classics&>(rhs);
		//cout << "operator>" << endl;
	if (releaseDate.year > r.releaseDate.year)
		return true;
	else if (releaseDate.year == r.releaseDate.year &&
			releaseDate.month > r.releaseDate.month)
		return true;
	else if(releaseDate.month == r.releaseDate.month &&
			releaseDate.year == r.releaseDate.year &&
			majorActor > r.majorActor)
		return true;
	else
		return false;
}

// ------------------------------------operator>------------------------------------
// Description: Takes in a Classic and compares it.
// ---------------------------------------------------------------------------------
bool Classics::operator>(const Classics &rhs) const {
	if (releaseDate.year > rhs.releaseDate.year)
		return true;
	else if (releaseDate.year == rhs.releaseDate.year &&
			releaseDate.month > rhs.releaseDate.month)
		return true;
	else if(releaseDate.month == rhs.releaseDate.month &&
			releaseDate.year == rhs.releaseDate.year &&
			majorActor > rhs.majorActor)
		return true;
	else
		return false;
}

// ------------------------------------operator<------------------------------------
// Description: Takes a Movie in as a parameter and converts it into a Classic,
//              and compares it.
// ---------------------------------------------------------------------------------
bool Classics::operator<(const Movie &rhs) const {
	const Classics& r = static_cast<const Classics&>(rhs);
	//cout << "operator<" << endl;
	if (releaseDate.year < r.releaseDate.year)
		return true;
	else if (releaseDate.year == r.releaseDate.year &&
			releaseDate.month < r.releaseDate.month)
		return true;
	else if(releaseDate.month == r.releaseDate.month &&
			releaseDate.year == r.releaseDate.year &&
			majorActor < r.majorActor)
		return true;
	else
		return false;
}

// ------------------------------------operator<------------------------------------
// Description: Takes a Classic in as a parameter and compares it
// ---------------------------------------------------------------------------------
bool Classics::operator<(const Classics &rhs) const {
	if (releaseDate.year < rhs.releaseDate.year)
			return true;
	else if (releaseDate.year == rhs.releaseDate.year &&
			releaseDate.month < rhs.releaseDate.month)
			return true;
	else if(releaseDate.month == rhs.releaseDate.month &&
			releaseDate.year == rhs.releaseDate.year &&
			majorActor < rhs.majorActor)
		return true;
	else
		return false;
}
