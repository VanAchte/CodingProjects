#ifndef C_H
#define C_H
#include <iostream>
#include "Movie.h"
using namespace std;

class Classics : public Movie {
	friend ostream & operator<<(ostream&, const Classics&);

public:
	Classics();
	~Classics();

	char getGenre();
	void buildMovie(string);
	virtual void printMovie();

	virtual bool operator>(const Classics &) const;
	virtual bool operator==(const Classics &) const;
	virtual bool operator<(const Classics &) const;

	virtual bool operator>(const Movie &) const;
	virtual bool operator==(const Movie &) const;
	virtual bool operator<(const Movie &) const;

private:

};
#endif
