#ifndef F_H
#define F_H
#include <iostream>
#include "Movie.h"
using namespace std;

class Comedy : public Movie {
public:
	Comedy(string);
	Comedy();
	~Comedy();
	char getGenre();

	void buildMovie(string);
	virtual void printMovie();

	virtual bool operator>(const Comedy &) const;
	virtual bool operator>(const Movie &) const;

	virtual bool operator==(const Comedy &) const;
	virtual bool operator==(const Movie &) const;


	virtual bool operator<(const Comedy &) const;
	virtual bool operator<(const Movie &) const;

	void setData(string);



private:

};
#endif
