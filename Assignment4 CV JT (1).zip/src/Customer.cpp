/*
 * Customer.cpp
 *
 *  Created on: Dec 9, 2016
 *      Author: ConorV
 */

#include "Customer.h"
using namespace std;

Customer::Customer(int idNum, string first, string last) {
	id = idNum;
    firstName = first;
    lastName = last;
}

Customer::Customer() {
    id = 0;
    firstName = "";
    lastName = "";
}

string Customer::getFullName() {
	return firstName + " " + lastName;
}
int Customer::getId() {
	return id;
}

bool Customer::compareId(const Customer& rhs)const {
	return (id == rhs.id);
}

bool Customer::isNull() {
	return id;
}

void Customer::addTransaction(){
	history.push_back(*trans);
}

void Customer::displayHistory() {

	for (int i = history.size() - 1; i >=0; i--) {
		cout << history.at(i).type << " ";
		history.at(i).movie->printMovie();
	
	}
}
void Customer::initTransaction(char typeT, Movie* movieName) {
    trans = new Transaction;
    trans->type = typeT;
    trans->movie = movieName;
}

Customer::~Customer() {

}
