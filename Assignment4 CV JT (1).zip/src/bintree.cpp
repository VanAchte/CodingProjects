// ------------------------------------------------ bintree.cpp -------------------------------------------------------
//
// Programmer Name: Conor Van Achte CSS343
// Creation Date: October 12, 2016
// Date of Last Modification: October 12, 2016
// --------------------------------------------------------------------------------------------------------------------
// Purpose: Allows creation of a BinaryTree which reads through a data file consisting of many lines, separated by $$.
//          Creates new Movie which contains strings with an undetermined length. Duplicated strings will be discarded,
//          smaller strings go to the left, larger strings to the right, alphabetically ordered.
// --------------------------------------------------------------------------------------------------------------------

#include "bintree.h"
using namespace std;
// ------------------------------------BinTree--------------------------------------
// Description: No argument constructor. Sets root to NULL.
// ---------------------------------------------------------------------------------
BinTree::BinTree() {
	root = NULL;
}
// ------------------------------------BinTree------------------------------------
// Description: Copy Constructor
// ----------------------------------------------------------------------------
BinTree::BinTree(const BinTree &copy) {
	root = NULL;
	*this = copy;
}

// ------------------------------------operator~------------------------------------
// Description: Destructor, delete the memory allocated for this tree's nodes.
// ----------------------------------------------------------------------------
BinTree::~BinTree() {
	makeEmpty();
}
// ------------------------------------retrieve------------------------------------
// Description: Looks throughout the tree to find the Movie data value that is
//              passed in.
// --------------------------------------------------------------------------------
bool BinTree::retrieve(const Movie &find, Movie* &ptr) {
	if (root != NULL && *(root->data) == find) {
		ptr = root->data;
		return true;
	} else {
		return retrieve(find, ptr, root);
	}
}
// ------------------------------------retrieve------------------------------------
// Description: Helper method for retrieve. takes in the data we need to find as
//              well as the ptr which is set to the found value if found. Also
//              passes in the root to recurively search throughout the tree.
// --------------------------------------------------------------------------------
bool BinTree::retrieve(const Movie &find, Movie* &ptr, Node* current) {
	// Base case =, return true if data is found and set pointer to the node.
	if (current){
		if (*current->data == find) {
			ptr = current->data;
			if (ptr->getGenre() == 'C')
			return true;
			// If it's not found check the left, if the data to the left is
			// less than the find value, but is NULL, the data is not in the tree.
		}
		else if (find < *current->data) {
			if (current->left == NULL) {
				return false;
			}
			else {
				return retrieve(find, ptr, current->left);
			}
			// If it's not found check the right, if the data to the right is
			// greater than the find value, but is NULL, the data is not in the tree.
		}
		else if (find > *current->data) {
			if (current->right == NULL) {
				return false;
			}
			else {
				return retrieve(find, ptr, current->right);
			}
		}
		else {
			return false;
		}
	}
	else{
		return false;
	}
}

// ------------------------------------operator=------------------------------------
// Description: Overloaded assignment operator. Takes in a BinTree and assign the
//              current object to the object passed in.
// ----------------------------------------------------------------------------
BinTree &BinTree::operator=(const BinTree &rhs) {
	if (!(*this == rhs)) {
		this->makeEmpty();
		root = NULL;
		this->copy(rhs.root);
	}
	return *this;
}
// ------------------------------------copy------------------------------------
// Description: Helper method for operator=, takes in the node and uses it to
//              recursively copy each Node.
// ----------------------------------------------------------------------------
void BinTree::copy(Node* current) {
	if (current != NULL) {
		Movie* add = new Movie(*current->data);
		insert(add);
		//Recursivly copy left and right.
		copy(current->left);
		copy(current->right);
	}
}
// ------------------------------------insert------------------------------------
// Description: Calls helper method insergt, sends the data and
//              the root to recursively check where to create a new node with
//              the data.
// ----------------------------------------------------------------------------
bool BinTree::insert(Movie* add) {
	return insert(add, root);
}
// ------------------------------------insert------------------------------------
// Description: Recursively goes through the BinTree to find where to place the new
//              node.
// ----------------------------------------------------------------------------
bool BinTree::insert(Movie* addData, Node*& currentNode) {
	if (currentNode == NULL) {
		currentNode = new Node();
		currentNode->data = addData;
		currentNode->left = NULL;
		currentNode->right = NULL;
		return true;
	} else if (*addData < *currentNode->data) {
		return insert(addData, currentNode->left);
	} else if (*addData > *currentNode->data) {
		return insert(addData, currentNode->right);
	}
	// If the data has been added already we return false.
	return false;
}
// ------------------------------------operator==------------------------------------
// Description: Compares two BinTree objects to see if they are equal or not. Uses a helper
//              method to recursively go through each node to check.
// ----------------------------------------------------------------------------
bool BinTree::operator==(const BinTree& rhs) const {
	return compareObjects(root, rhs.root);
}
// ------------------------------------operator==------------------------------------
// Description: Private method used by operator== to recursively check each node.
// ----------------------------------------------------------------------------
bool BinTree::compareObjects(Node* left, Node* right) const {
	// Compares  the left and right, to make sure we don't over run our bounds
	if (right == NULL && left == NULL) {
		return true;
	}
	// If they both aren't NULL we need to check through the rest of trees.
	// Check the data first, then check each's left, then each's right.
	if (right != NULL && left != NULL) {
		return (*left->data == *right->data
				&& compareObjects(left->left, right->left)
				&& compareObjects(left->right, right->right));
	}
	return false;
}
// ------------------------------------operator!=------------------------------------
// Description: Overloaded != operator. Compares two BinTree objects
// ----------------------------------------------------------------------------------
bool BinTree::operator!=(const BinTree & rhs) const {
	return !(*this == rhs);
}

// ------------------------------------isEmpty------------------------------------
// Description: Checks if the root is empty, if it is return true.
// -------------------------------------------------------------------------------
bool BinTree::isEmpty() const {
	return root == NULL;

}
// ------------------------------------makeEmpty------------------------------------
// Description: Makes the tree empty by going to the bottom of the tree and
//              deleting all of the leafs first, then traverses up the tree,
//              deleting the leaf nodes on the way back up.
// -------------------------------------------------------------------------------
void BinTree::makeEmpty() {
	if (!isEmpty()) {
		makeEmpty(root);
	}
}
// ------------------------------------makeEmpty------------------------------------
// Description: Helper method for makeEmpty, takes in the root to recursively
//              traverse through the tree.
// -------------------------------------------------------------------------------
void BinTree::makeEmpty(Node* &current) {
	if (current != NULL) {
		makeEmpty(current->left);
		makeEmpty(current->right);
		delete current->data;
		delete current;
		current = NULL;
	}
}
//-------------------------- operator<< --------------------------------------
// Description: Helper method for makeEmpty, takes in the root to recursively
//              traverse through the tree.
// -------------------------------------------------------------------------------
ostream& operator<<(ostream& output, const BinTree &print) {

	return output;
}

//------------------------- displaySideways ---------------------------------
// Displays a binary tree as though you are viewing it from the side;
// hard coded displaying to standard output.
// Preconditions: NONE
// Postconditions: BinTree remains unchanged.
void BinTree::displaySideways() const {
	sideways(root);
}
//---------------------------- Sideways -------------------------------------
// Helper method for displaySideways
// Preconditions: NONE
// Postconditions: BinTree remains unchanged.
// dOn't ask cause i didn't wannnnnna change it
void BinTree::sideways(Node* current) const {

	if (current != NULL) {
		sideways(current->left);

		cout << "Genre: " << current->data->getGenre() << " Stock: ";
		cout << current->data->getStock() << " Director: " << current->data->getDirector();
		cout << " Title: " << current->data->getTitle();
		if (current->data->getMonth()){
			cout << " Release Month: " << current->data->getMonth() << " Major Actor: " << current->data->getMajorActor();
		}
		cout << " Release Year: " << current->data->getYear() << endl << endl;

		sideways(current->right);
	}
}
