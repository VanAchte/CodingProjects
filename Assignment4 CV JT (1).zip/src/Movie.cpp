/*
 * Movie.cpp

 *
 *  Created on: Dec 8, 2016
 *      Author: Conor
 */

#include "Movie.h"
#include "Drama.h"
#include "Comedy.h"
#include "Classics.h"
#include <sstream>
using namespace std;

Movie::Movie(char type, string line){
    stock = 0;
}

Movie::Movie() {

}
void Movie::setYear(int s) {
	releaseDate.year = s;
}

void Movie::setMajorActor(string MA){
	majorActor = MA;
}

void Movie::setMonth(int m){
	releaseDate.month = m;
}
void Movie::setTitle(string s) {
	title = s;
}

char Movie::getGenre() {
	return '0';
}

string Movie::getDirector() {
	return director;
}

void Movie::setDirector(string d){
	director = d;
}

int Movie::getYear() {
	return releaseDate.year;
}

string Movie::getTitle(){
	return title;
}

string Movie::getUntilComma(string s) {
    string total = "";
    int length = s.length();
    for(int i = 0; i < length; i++) {
    	if(s.at(i) == ',') {
    		break;
    	}
    	total = total + s.at(i);
    }
	return total;
}

string Movie::getUntilSpace(string s) {
    string total = "";
    int length = s.length();
    for(int i = 0; i < length; i++) {
    	if(s.at(i) == ' ') {
    		break;
    	}
    	total = total + s.at(i);
    }
	return total;
}

Movie::~Movie() {

}

int Movie::stringToInt(string s) {
	int total;
	stringstream convert(s);
	if( !(convert >> total) ) {
		total = 0;
	}
	return total;
}

void Movie::setStock(int stockNum) {
		stock = stockNum;
}
int Movie::getStock() {
	return stock;
}
string Movie::removeToComma(string mod) {
    string newString = "";
    int length = mod.length();
    for(int i = 0; i < length; i++) {
    	if(mod.at(i) == ',') {
    		// If we hit a ',' then return a string + 2 from the comma
    		// to get rid of the comma and the space between data values.
    		newString = mod.substr(i + 2, mod.length() - 1);
    		break;
    	}
    }
	return newString;
}
string Movie::removeToSpace(string mod) {
    string newString = "";
    int length = mod.length();
    for(int i = 0; i < length; i++) {
    	if(mod.at(i) == ' ') {
    		// If we hit a ',' then return a string + 2 from the comma
    		// to get rid of the comma and the space between data values.
    		newString = mod.substr(i + 1, mod.length() - 1);
    		break;
    	}

    }
	return newString;
}
string Movie::getMajorActor() {
	return majorActor;
}
int Movie::getMonth() {
	return releaseDate.month;
}

void Movie::printMovie(){

}

bool Movie:: operator==(const Movie& rhs) const{
	return true;
}

bool Movie:: operator<(const Movie& rhs) const{
	return true;
}

bool Movie::operator>(const Movie &rhs) const {
	return true;
}

void Movie::buildMovie(string line) {

}
Movie* Movie::getMovie() {
    return this;

}
