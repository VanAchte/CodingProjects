#ifndef H_T
#define H_T
#include <iostream>
#include "Customer.h"
using namespace std;

class HashTable {

public:
	HashTable();
	~HashTable();
	HashTable(int);

	bool add(int, Customer*);
	void printArr();

	Customer& getById(int);
	Customer& removeById(int);

	Customer* retrieve(int);

private:
	struct ArrayItem
	{
		// Set to 0, if still 0 it is considered NULL
		int key = 0;
		Customer* item = NULL;
	};

	int length;

	void initArray(int);
	ArrayItem* customerList;
	int h(int);

	bool isFull();
	int getIndexById(int);

	Customer* find(int, int);

};

#endif
