/*
 * Customer.h
 *
 *  Created on: Dec 9, 2016
 *      Author: ConorV
 */

#ifndef CUSTOMER_H_
#define CUSTOMER_H_

#include<iostream>
#include"Movie.h"
//#include "HashTable.h"
#include<vector>

using namespace std;

struct date
{
	int month;
	int day;
	int year;
};


struct Transaction
{
	// borrow or returned
	char type;
	Movie* movie;
//  date transDate;
//	int year;
//	char genre;
//	string movie;
//	string actor;

};

class Customer {

public:
	~Customer();
	Customer(int, string, string);
	Customer();
	void borrow(const Movie&);
	void returnMovie(const Movie&);
	void printHistory();
    bool compareId(const Customer&)const;
    bool isNull();
    int getId();
    string getFullName();
    void initTransaction(char, Movie*);
    void addTransaction();
    void displayHistory();

private:
	vector<Transaction> history;
	int id;
	string firstName;
	string lastName;
	Transaction *trans;
};

#endif /* CUSTOMER_H_ */
