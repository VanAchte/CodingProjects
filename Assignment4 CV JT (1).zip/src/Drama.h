#ifndef D_H
#define D_H
#include <iostream>
#include "Movie.h"
using namespace std;

class Drama : public Movie {

public:
	Drama();
	~Drama();

	char getGenre();
	virtual void printMovie();

	virtual bool operator==(const Drama &) const;
	virtual bool operator>(const Drama &) const;
	virtual bool operator<(const Drama &) const;

	virtual bool operator==(const Movie &) const;
	virtual bool operator>(const Movie &) const;
	virtual bool operator<(const Movie &) const;

	void setStock(int);
	void buildMovie(string);
    int getYear();
    string getDirector();

private:

};
#endif
