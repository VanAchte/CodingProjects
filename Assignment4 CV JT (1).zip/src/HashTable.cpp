/*
 * HashTable.cpp.h
 *
 *  Created on: Dec 9, 2016
 *      Author: ConorV
 */
#include"HashTable.h"

void HashTable::printArr(){
	for (int i = 0; i < length; i++)
	{
		if (customerList[i].item){
			cout << customerList[i].item->getFullName() << endl;
		}

	}
}

HashTable::HashTable() {
	length = 997;
	initArray(length);

}
HashTable::HashTable(int size) {
	length = 2000;
	initArray(length);
}

HashTable::~HashTable(){
	for (int i = 0; i < length; i++){

		if (customerList[i].key != 0)
			delete customerList[i].item;
	}
}

void HashTable::initArray(int size) {
	customerList = new ArrayItem[size];

	for (int i = 0; i < size; i++) {
		customerList[i].key = 0;
		customerList[i].item = NULL;
	}
}

Customer& HashTable::getById(int id) {
	int location = id % length;
	if (customerList[location].item != NULL){
		if (customerList[location].item->getId() == id)
			return *customerList[location].item;
		else {
			Customer* found = find(location, id);
			return *found;
		}
	}
}

Customer* HashTable::retrieve(int idNum) {
	int location = idNum % length;
	if (customerList[location].item != NULL){
		if (customerList[location].item->getId() == idNum)
			return customerList[location].item;
		else {
			Customer* found = find(location, idNum);
			return found;
		}
	}
	return NULL;
}

Customer* HashTable::find(int location, int id) {
	if (customerList[location].key == 0)
		return NULL;
	else if (customerList[location].key == id)
		return customerList[location].item;
	else
		return find((location + 1) % length,  id);
}

bool HashTable::add(int id, Customer* newCustomer) {
	int hash = id % length;
	if (customerList[hash].key == 0) {
		customerList[hash].key = newCustomer->getId();
		customerList[hash].item = newCustomer;
		return true;
	} else {
		while (customerList[hash].key != 0)
			hash = (hash + 1) % length;

		customerList[hash].key = newCustomer->getId();
		customerList[hash].item = newCustomer;
		return true;
	}
}

